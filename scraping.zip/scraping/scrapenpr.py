import requests
from bs4 import BeautifulSoup
import spacy
from spacy import displacy

def soup_filter(els):
    allowed = ['p']
    for el in els:
        if el.parent.name in allowed:
            return True
        return False

def text_from_html(data):
    soup = BeautifulSoup(data, 'html.parser')
    els = soup.find_all(text=True, class_=False)
    els = filter(soup_filter, els)
    return u" ".join([el.get_text() for el in els])

def visualize(textdata):
    doc = nlp(textdata)
    displacy.serve(doc, style='ent')

nlp = spacy.load('en_core_web_sm')

url = 'https://www.npr.org/2022/07/01/1109476072/india-plastics-ban-begins'
data = requests.get(url).text
textdata = text_from_html(data)
visualize(textdata)